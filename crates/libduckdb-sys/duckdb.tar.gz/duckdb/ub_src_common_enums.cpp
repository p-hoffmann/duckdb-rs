#include "src/common/enums/catalog_type.cpp"

#include "src/common/enums/compression_type.cpp"

#include "src/common/enums/date_part_specifier.cpp"

#include "src/common/enums/expression_type.cpp"

#include "src/common/enums/file_compression_type.cpp"

#include "src/common/enums/join_type.cpp"

#include "src/common/enums/logical_operator_type.cpp"

#include "src/common/enums/metric_type.cpp"

#include "src/common/enums/optimizer_type.cpp"

#include "src/common/enums/physical_operator_type.cpp"

#include "src/common/enums/statement_type.cpp"

#include "src/common/enums/relation_type.cpp"

