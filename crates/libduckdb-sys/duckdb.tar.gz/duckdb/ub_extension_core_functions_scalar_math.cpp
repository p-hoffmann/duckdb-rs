#include "extension/core_functions/scalar/math/numeric.cpp"

