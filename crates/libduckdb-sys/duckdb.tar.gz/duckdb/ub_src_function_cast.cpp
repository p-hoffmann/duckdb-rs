#include "src/function/cast/array_casts.cpp"

#include "src/function/cast/blob_cast.cpp"

#include "src/function/cast/bit_cast.cpp"

#include "src/function/cast/cast_function_set.cpp"

#include "src/function/cast/decimal_cast.cpp"

#include "src/function/cast/default_casts.cpp"

#include "src/function/cast/enum_casts.cpp"

#include "src/function/cast/list_casts.cpp"

#include "src/function/cast/map_cast.cpp"

#include "src/function/cast/numeric_casts.cpp"

#include "src/function/cast/pointer_cast.cpp"

#include "src/function/cast/string_cast.cpp"

#include "src/function/cast/struct_cast.cpp"

#include "src/function/cast/time_casts.cpp"

#include "src/function/cast/union_casts.cpp"

#include "src/function/cast/uuid_casts.cpp"

#include "src/function/cast/varint_casts.cpp"

#include "src/function/cast/vector_cast_helpers.cpp"

