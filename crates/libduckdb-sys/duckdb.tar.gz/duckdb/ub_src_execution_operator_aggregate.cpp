#include "src/execution/operator/aggregate/aggregate_object.cpp"

#include "src/execution/operator/aggregate/distinct_aggregate_data.cpp"

#include "src/execution/operator/aggregate/physical_hash_aggregate.cpp"

#include "src/execution/operator/aggregate/grouped_aggregate_data.cpp"

#include "src/execution/operator/aggregate/physical_partitioned_aggregate.cpp"

#include "src/execution/operator/aggregate/physical_perfecthash_aggregate.cpp"

#include "src/execution/operator/aggregate/physical_ungrouped_aggregate.cpp"

#include "src/execution/operator/aggregate/physical_window.cpp"

#include "src/execution/operator/aggregate/physical_streaming_window.cpp"

